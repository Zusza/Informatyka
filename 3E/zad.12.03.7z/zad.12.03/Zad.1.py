with open("wielomian.txt", "r") as plik:
    for i in plik:
        a = int(i.split())
        x = int(i.split())
        ciag = list(map(int, i.split()))

n = len(ciag)

for i in range(n):
    a = a * x + ciag[i]
print(a)

