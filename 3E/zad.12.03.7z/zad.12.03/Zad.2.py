with open("ciagi.txt", "r") as plik:
    for i in plik:
        ciag = list(map(int, i.split()))

n = len(ciag)
sum = 0

for i in range(n-1):
    if ciag[i] > ciag[i-1]:
        sum += 1
print(sum)