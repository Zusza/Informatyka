plik = open("liczby.txt", "r")
ciag = list(map(int, plik.readline().split()))
plik.close()

n = len(ciag)

for i in range(n - 2):
    liczby = ciag[i:i+3]
    suma = sum(liczby)
    if  suma < 0:
        print(liczby)